function AccountPermissions() {
  return <>AccountPermissions</>;
}

export default AccountPermissions;
