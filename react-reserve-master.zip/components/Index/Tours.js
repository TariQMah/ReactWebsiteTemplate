import TourCard from "../TourCard/TourCard";
function Tours() {
  const elements = [
    "product1",
    "product2",
    "product3",
    "product1",
    "product2",
    "product3"
  ];

  return (
    <section id="col-3-tours">
      <div className="container">
        <div className="trending-tour__tittle">
          <div className="section-tittle">
            <h2>Trending Tour</h2>
            <div className="section-tittle__line-under"></div>
            <p>
              Trending <span>Tour</span>
            </p>
          </div>
        </div>
        <div className="row">
          {elements.map((value, index) => {
            return (
              <div className="col-lg-4 col-sm-6 col-12">
                <TourCard package={elements} />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default Tours;
