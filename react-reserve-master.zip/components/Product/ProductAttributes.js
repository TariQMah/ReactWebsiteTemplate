function ProductAttributes() {
  return <>ProductAttributes</>;
}

export default ProductAttributes;
