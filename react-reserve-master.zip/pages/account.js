function Account() {
  return <>account</>;
}

export default Account;
