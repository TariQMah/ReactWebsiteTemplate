function CreateProduct() {
  return <>create</>;
}

export default CreateProduct;
