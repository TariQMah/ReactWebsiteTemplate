import TopDestination from "../components/Index/TopDestination";
import Tours from "../components/Index/Tours";
import Video from "../components/Index/Video";
import TravelTips from "../components/Index/TravelTips";

function Home() {
  return (
    <>
      <TopDestination />
      <Tours />
      <Video />
      <TravelTips />
    </>
  );
}

export default Home;
