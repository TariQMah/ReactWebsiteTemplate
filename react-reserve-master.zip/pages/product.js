function Product() {
  return <>product</>;
}

export default Product;
